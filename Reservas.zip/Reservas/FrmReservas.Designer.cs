﻿namespace Reservas
{
    partial class FrmReservas
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.rESERVASDataSet = new Reservas.RESERVASDataSet();
            this.rESERVASBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rESERVASTableAdapter = new Reservas.RESERVASDataSetTableAdapters.RESERVASTableAdapter();
            this.Sede = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TipoHabitacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CantidadTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CantidadReservada = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CantidadDisponible = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PersonasxHabitacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnReservar = new FontAwesome.Sharp.IconButton();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rESERVASDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rESERVASBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.SteelBlue;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(173, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(425, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "GESTIÓN DE RESERVAS";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(12, 90);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(785, 357);
            this.panel1.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Sede,
            this.TipoHabitacion,
            this.CantidadTotal,
            this.CantidadReservada,
            this.CantidadDisponible,
            this.fechas,
            this.PersonasxHabitacion});
            this.dataGridView1.DataSource = this.rESERVASBindingSource;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(785, 357);
            this.dataGridView1.TabIndex = 0;
            // 
            // rESERVASDataSet
            // 
            this.rESERVASDataSet.DataSetName = "RESERVASDataSet";
            this.rESERVASDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // rESERVASBindingSource
            // 
            this.rESERVASBindingSource.DataMember = "RESERVAS";
            this.rESERVASBindingSource.DataSource = this.rESERVASDataSet;
            // 
            // rESERVASTableAdapter
            // 
            this.rESERVASTableAdapter.ClearBeforeFill = true;
            // 
            // Sede
            // 
            this.Sede.DataPropertyName = "Sede";
            this.Sede.HeaderText = "Sede";
            this.Sede.MinimumWidth = 6;
            this.Sede.Name = "Sede";
            this.Sede.Width = 125;
            // 
            // TipoHabitacion
            // 
            this.TipoHabitacion.DataPropertyName = "TipoHabitacion";
            this.TipoHabitacion.HeaderText = "Tipo de Habitación";
            this.TipoHabitacion.MinimumWidth = 6;
            this.TipoHabitacion.Name = "TipoHabitacion";
            this.TipoHabitacion.Width = 125;
            // 
            // CantidadTotal
            // 
            this.CantidadTotal.DataPropertyName = "CantidadTotal";
            this.CantidadTotal.HeaderText = "Cantidad de habitaciones";
            this.CantidadTotal.MinimumWidth = 6;
            this.CantidadTotal.Name = "CantidadTotal";
            this.CantidadTotal.Width = 125;
            // 
            // CantidadReservada
            // 
            this.CantidadReservada.DataPropertyName = "CantidadReservada";
            this.CantidadReservada.HeaderText = "Cantidad de habitaciones reservadas";
            this.CantidadReservada.MinimumWidth = 6;
            this.CantidadReservada.Name = "CantidadReservada";
            this.CantidadReservada.Width = 125;
            // 
            // CantidadDisponible
            // 
            this.CantidadDisponible.DataPropertyName = "CantidadDisponible";
            this.CantidadDisponible.HeaderText = "Cantidad de habitaciones disponibles";
            this.CantidadDisponible.MinimumWidth = 6;
            this.CantidadDisponible.Name = "CantidadDisponible";
            this.CantidadDisponible.Width = 125;
            // 
            // fechas
            // 
            this.fechas.DataPropertyName = "fechas";
            this.fechas.HeaderText = "Fechas";
            this.fechas.MinimumWidth = 6;
            this.fechas.Name = "fechas";
            this.fechas.Width = 125;
            // 
            // PersonasxHabitacion
            // 
            this.PersonasxHabitacion.DataPropertyName = "PersonasxHabitacion";
            this.PersonasxHabitacion.HeaderText = "Personas por habitación";
            this.PersonasxHabitacion.MinimumWidth = 6;
            this.PersonasxHabitacion.Name = "PersonasxHabitacion";
            this.PersonasxHabitacion.Width = 125;
            // 
            // btnReservar
            // 
            this.btnReservar.IconChar = FontAwesome.Sharp.IconChar.None;
            this.btnReservar.IconColor = System.Drawing.Color.Black;
            this.btnReservar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.btnReservar.Location = new System.Drawing.Point(868, 150);
            this.btnReservar.Name = "btnReservar";
            this.btnReservar.Size = new System.Drawing.Size(96, 50);
            this.btnReservar.TabIndex = 2;
            this.btnReservar.Text = "Reservar";
            this.btnReservar.UseVisualStyleBackColor = true;
            this.btnReservar.Click += new System.EventHandler(this.btnReservar_Click);
            // 
            // FrmReservas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 523);
            this.Controls.Add(this.btnReservar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Name = "FrmReservas";
            this.Text = "Reservas";
            this.Load += new System.EventHandler(this.FrmReservas_Load_1);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rESERVASDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rESERVASBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private RESERVASDataSet rESERVASDataSet;
        private System.Windows.Forms.BindingSource rESERVASBindingSource;
        private RESERVASDataSetTableAdapters.RESERVASTableAdapter rESERVASTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn Sede;
        private System.Windows.Forms.DataGridViewTextBoxColumn TipoHabitacion;
        private System.Windows.Forms.DataGridViewTextBoxColumn CantidadTotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn CantidadReservada;
        private System.Windows.Forms.DataGridViewTextBoxColumn CantidadDisponible;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechas;
        private System.Windows.Forms.DataGridViewTextBoxColumn PersonasxHabitacion;
        private FontAwesome.Sharp.IconButton btnReservar;
    }
}

