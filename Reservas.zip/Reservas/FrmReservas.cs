﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using Negocio;
using FontAwesome.Sharp;

namespace Reservas
{
    public partial class FrmReservas : Form
    {
        private static IconMenuItem menuActivo = null;

        public FrmReservas()
        {
            InitializeComponent();
        }

        private void FrmReservas_Load(object sender, EventArgs e)
        {
            List<Reserva> listReserva = new CN_Reserva().Listar();


            foreach (Reserva item in listReserva)
            {
                dataGridView1.Rows.Add(new object[]{ item.Sede, item.TipoHabitacion, item.CantidadTotal, item.CantidadReservada, item.CantidadDisponible,
                        item.fechas, item.PersonasxHabitacion
                });
            }
        }

        private void AbrirFormulario(IconMenuItem menu, Form formulario)
        {
            if(menuActivo != null)
            {
                menuActivo.BackColor = Color.White;
            }

            menu.BackColor = Color.Silver;
            menuActivo = menu;

        }

        private void menuReservas(object sender, EventArgs e)
        {
            AbrirFormulario((IconMenuItem)sender, new FrmReservas());
        }

        private void FrmReservas_Load_1(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'rESERVASDataSet.RESERVAS' Puede moverla o quitarla según sea necesario.
            this.rESERVASTableAdapter.Fill(this.rESERVASDataSet.RESERVAS);

        }

        private void btnReservar_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.ToString();
        }
    }
}
