﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data;
using Entidades;

namespace Negocio
{
    public class CN_Reserva
    {
        private CD_Reservas objCD_Reserva = new CD_Reservas();

        public List<Reserva> Listar()
        {
            return objCD_Reserva.Listar();
        }
    }
}
