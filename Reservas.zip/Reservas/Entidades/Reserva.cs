﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Reserva
    {
        public int idRserva { get; set; }
        public string Sede { get; set; }
        public string TipoHabitacion { get; set; }
        public int CantidadTotal { get; set; }
        public int CantidadReservada { get; set; }
        public int CantidadDisponible { get; set; }
        public string fechas { get; set; }
        public int PersonasxHabitacion { get; set; }

    }
}
