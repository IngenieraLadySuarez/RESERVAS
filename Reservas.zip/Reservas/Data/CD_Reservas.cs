﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Entidades;

namespace Data
{
    public class CD_Reservas
    {
        public List<Reserva> Listar()
        {
            List<Reserva> list = new List<Reserva>();

            using (SqlConnection oconection = new SqlConnection(Coneccion.chain))
            {
                try
                {
                    string query = "select * from Reservas";

                    SqlCommand cmd = new SqlCommand(query, oconection);
                    cmd.CommandType = CommandType.Text;

                    oconection.Open();

                    using (SqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            list.Add(new Reserva()
                            {
                                idRserva = Convert.ToInt32(dr["ID"]),
                                Sede = dr["Sede"].ToString(),
                                TipoHabitacion = dr["TipoHabitacion"].ToString(),
                                CantidadTotal= Convert.ToInt32(dr["CantidadTotal"]),
                                CantidadReservada = Convert.ToInt32(dr["CantidadReservada"]),
                                CantidadDisponible = Convert.ToInt32(dr["CantidadDisponible"]),
                                fechas =  dr["fechas"].ToString(),
                                PersonasxHabitacion= Convert.ToInt32(dr["PersonasxHabitacion"]),

                            });
                        }
                    }
                }
                catch (Exception ex)
                {
                    list = new List<Reserva>();
                }
            }
            return list;
        }
    }
}
